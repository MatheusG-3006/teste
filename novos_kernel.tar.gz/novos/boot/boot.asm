; =============================================================
;  NovOS Bootloader — boot.asm
;  Roda em modo real 16-bit, carrega o kernel e entra em
;  modo protegido 32-bit (Protected Mode)
; =============================================================

[BITS 16]
[ORG 0x7C00]          ; BIOS sempre carrega o boot aqui

KERNEL_OFFSET equ 0x1000  ; onde o kernel será carregado na RAM

start:
    ; Zera registradores de segmento
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00        ; pilha cresce para baixo a partir do boot

    mov [BOOT_DRIVE], dl  ; salva drive (BIOS passa em DL)

    ; Mostra mensagem de boot
    mov si, MSG_BOOT
    call print_string

    ; Carrega kernel do disco para 0x1000
    call load_kernel

    ; Entra em modo protegido 32-bit
    call switch_to_pm

    jmp $                 ; nunca chega aqui

; -------------------------------------------------------------
;  Carrega 32 setores do disco (16 KB) para KERNEL_OFFSET
; -------------------------------------------------------------
load_kernel:
    mov si, MSG_LOAD
    call print_string

    mov bx, KERNEL_OFFSET ; destino na memória
    mov dh, 32            ; 32 setores
    mov dl, [BOOT_DRIVE]
    call disk_load
    ret

; -------------------------------------------------------------
;  Leitura de disco via interrupção BIOS 0x13
; -------------------------------------------------------------
disk_load:
    push dx
    mov ah, 0x02          ; função: ler setores
    mov al, dh            ; número de setores
    mov ch, 0x00          ; cilindro 0
    mov cl, 0x02          ; começa no setor 2 (setor 1 = boot)
    mov dh, 0x00          ; cabeça 0
    int 0x13              ; chamada BIOS
    jc disk_error         ; CF=1 significa erro
    pop dx
    cmp al, dh
    jne sectors_error
    ret

disk_error:
    mov si, MSG_DISK_ERR
    call print_string
    jmp $

sectors_error:
    mov si, MSG_SEC_ERR
    call print_string
    jmp $

; -------------------------------------------------------------
;  Imprime string terminada em null via BIOS
; -------------------------------------------------------------
print_string:
    mov ah, 0x0E          ; modo teletype BIOS
.loop:
    lodsb                 ; carrega byte de [SI] em AL
    test al, al
    jz .done
    int 0x10              ; imprime caractere
    jmp .loop
.done:
    ret

; -------------------------------------------------------------
;  GDT — Global Descriptor Table (define segmentos 32-bit)
; -------------------------------------------------------------
gdt_start:

gdt_null:               ; descritor nulo obrigatório
    dd 0x0
    dd 0x0

gdt_code:               ; segmento de código: base=0, lim=4GB, exec/leitura
    dw 0xFFFF           ; limite [15:0]
    dw 0x0000           ; base  [15:0]
    db 0x00             ; base  [23:16]
    db 10011010b        ; acesso: presente, ring0, código, exec, leitura
    db 11001111b        ; flags: 32-bit, granularidade 4KB + limite[19:16]
    db 0x00             ; base  [31:24]

gdt_data:               ; segmento de dados: base=0, lim=4GB, leitura/escrita
    dw 0xFFFF
    dw 0x0000
    db 0x00
    db 10010010b        ; acesso: presente, ring0, dados, escrita
    db 11001111b
    db 0x00

gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1   ; tamanho da GDT
    dd gdt_start                  ; endereço da GDT

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

; -------------------------------------------------------------
;  Muda para modo protegido 32-bit
; -------------------------------------------------------------
switch_to_pm:
    cli                   ; desabilita interrupções
    lgdt [gdt_descriptor] ; carrega GDT
    mov eax, cr0
    or  eax, 0x1          ; bit PE = Protected Mode Enable
    mov cr0, eax
    jmp CODE_SEG:init_pm  ; far jump para limpar pipeline e ir a 32-bit

[BITS 32]
init_pm:
    ; Configura segmentos de dados para 32-bit
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ebp, 0x90000      ; pilha 32-bit
    mov esp, ebp

    call KERNEL_OFFSET    ; *** salta para o kernel C! ***

    jmp $

; -------------------------------------------------------------
;  Dados
; -------------------------------------------------------------
BOOT_DRIVE    db 0
MSG_BOOT      db "NovOS Bootloader iniciando...", 13, 10, 0
MSG_LOAD      db "Carregando kernel Aether...", 13, 10, 0
MSG_DISK_ERR  db "ERRO: falha no disco!", 13, 10, 0
MSG_SEC_ERR   db "ERRO: setores incorretos!", 13, 10, 0

; Preenche até 510 bytes e adiciona assinatura de boot
times 510 - ($ - $$) db 0
dw 0xAA55             ; magic number — BIOS valida isso
