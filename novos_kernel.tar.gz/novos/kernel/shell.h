// =============================================================
//  NovOS — kernel/shell.h
//  NovShell — interpretador de comandos do NovOS
// =============================================================

#ifndef SHELL_H
#define SHELL_H

#include "../include/types.h"
#include "../drivers/vga.h"
#include "../drivers/keyboard.h"
#include "memory.h"
#include "scheduler.h"

#define CMD_MAX_LEN  80
#define CMD_MAX_ARGS  8

// =============================================================
//  Utilitários de string (sem libc)
// =============================================================
static int kstrlen(const char* s) {
    int n = 0; while (s[n]) n++; return n;
}

static int kstrcmp(const char* a, const char* b) {
    while (*a && *a == *b) { a++; b++; }
    return *a - *b;
}

static int kstrncmp(const char* a, const char* b, int n) {
    while (n-- && *a && *a == *b) { a++; b++; }
    return n < 0 ? 0 : *a - *b;
}

// Divide string em argumentos pelo espaço
static int parse_args(char* cmd, char* args[], int max) {
    int argc = 0;
    char* p = cmd;
    while (*p && argc < max) {
        while (*p == ' ') p++;
        if (!*p) break;
        args[argc++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = '\0';
    }
    return argc;
}

// =============================================================
//  Eco de tecla para tela
// =============================================================
static void echo_char(char c) { vga_putchar(c); }

// =============================================================
//  Comandos do NovShell
// =============================================================

static void cmd_help(void) {
    vga_set_color(COLOR_LCYAN, COLOR_BLACK);
    vga_print("\n  Comandos do NovShell:\n");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("  ajuda      - mostra esta mensagem\n");
    vga_print("  sobre      - informacoes do NovOS\n");
    vga_print("  memoria    - uso de memoria RAM\n");
    vga_print("  processos  - lista processos ativos\n");
    vga_print("  limpar     - limpa a tela\n");
    vga_print("  eco <txt>  - repete o texto\n");
    vga_print("  hex <n>    - converte decimal para hex\n");
    vga_print("  cor <n>    - muda cor do terminal (0-14)\n");
    vga_print("  pag        - aloca pagina de memoria\n");
    vga_print("  reboot     - reinicia o sistema\n\n");
}

static void cmd_sobre(void) {
    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("\n  +-------------------------------+\n");
    vga_print("  |   NovOS v1.0 - Kernel Aether  |\n");
    vga_print("  |   Sistema Operacional Proprio  |\n");
    vga_print("  +-------------------------------+\n");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("  Kernel :  Aether 1.0 (32-bit Protected Mode)\n");
    vga_print("  FS     :  Vortex (simulado)\n");
    vga_print("  Sched  :  Round-Robin\n");
    vga_print("  Mem    :  Bitmap Allocator + Bump Heap\n");
    vga_print("  Arch   :  x86 (i386)\n\n");
}

static void cmd_memoria(void) {
    vga_set_color(COLOR_YELLOW, COLOR_BLACK);
    vga_print("\n  Memoria RAM:\n");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("  Total : ");
    vga_print_num(mem_total_kb());
    vga_print(" KB\n");
    vga_print("  Usada : ");
    vga_print_num(mem_used_kb());
    vga_print(" KB\n");
    vga_print("  Livre : ");
    vga_print_num(mem_free_kb());
    vga_print(" KB\n\n");
}

static void cmd_processos(void) {
    vga_set_color(COLOR_YELLOW, COLOR_BLACK);
    vga_print("\n");
    proc_list(vga_print, vga_print_num);
    vga_print("\n");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
}

static void cmd_eco(char* args[], int argc) {
    vga_print("  ");
    for (int i = 1; i < argc; i++) {
        vga_print(args[i]);
        if (i < argc-1) vga_putchar(' ');
    }
    vga_putchar('\n');
}

static void cmd_hex(char* args[], int argc) {
    if (argc < 2) { vga_print("  uso: hex <numero>\n"); return; }
    // Converte string para número
    u32 n = 0;
    char* s = args[1];
    while (*s >= '0' && *s <= '9') n = n*10 + (*s++ - '0');
    vga_print("  ");
    vga_print_num(n);
    vga_print(" = ");
    vga_print_hex(n);
    vga_putchar('\n');
}

static void cmd_cor(char* args[], int argc) {
    if (argc < 2) { vga_print("  uso: cor <0-14>\n"); return; }
    u32 c = 0;
    char* s = args[1];
    while (*s >= '0' && *s <= '9') c = c*10 + (*s++ - '0');
    if (c > 14) c = 14;
    vga_set_color((VGAColor)c, COLOR_BLACK);
    vga_print("  Cor alterada para ");
    vga_print_num(c);
    vga_putchar('\n');
}

static void cmd_pag(void) {
    void* p = page_alloc();
    if (p) {
        vga_print("  Pagina alocada em: ");
        vga_print_hex((u32)p);
        vga_putchar('\n');
    } else {
        vga_set_color(COLOR_LRED, COLOR_BLACK);
        vga_print("  ERRO: sem paginas livres!\n");
        vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    }
}

static void cmd_reboot(void) {
    vga_set_color(COLOR_LRED, COLOR_BLACK);
    vga_print("\n  Reiniciando...\n");
    // Pulso no teclado PS/2 para reset via linha de reset da CPU
    u8 tmp = 0;
    while (tmp & 0x02) tmp = inb(0x64);
    // Envia comando 0xFE (reset CPU) via controlador de teclado
    __asm__ volatile ("outb %0, %1" :: "a"((u8)0xFE), "Nd"((u16)0x64));
    // Loop infinito se o reboot não ocorrer
    while (1) __asm__ volatile ("hlt");
}

static void cmd_desconhecido(const char* cmd) {
    vga_set_color(COLOR_LRED, COLOR_BLACK);
    vga_print("  novshell: comando nao encontrado: '");
    vga_print(cmd);
    vga_print("'\n  Digite 'ajuda' para ver os comandos.\n");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
}

// =============================================================
//  Loop principal do shell
// =============================================================
void shell_run(void) {
    char cmd_buf[CMD_MAX_LEN];
    char* args[CMD_MAX_ARGS];

    while (1) {
        // Prompt
        vga_set_color(COLOR_LGREEN, COLOR_BLACK);
        vga_print("root");
        vga_set_color(COLOR_LGRAY, COLOR_BLACK);
        vga_print("@novos");
        vga_set_color(COLOR_LCYAN, COLOR_BLACK);
        vga_print(" ~ ");
        vga_set_color(COLOR_WHITE, COLOR_BLACK);
        vga_print("$ ");
        vga_set_color(COLOR_LGRAY, COLOR_BLACK);

        // Lê comando
        kb_readline(cmd_buf, CMD_MAX_LEN, echo_char);

        // Ignora linha vazia
        if (cmd_buf[0] == '\0') continue;

        // Parse de argumentos
        int argc = parse_args(cmd_buf, args, CMD_MAX_ARGS);
        if (argc == 0) continue;

        // Despacha comando
        if      (kstrcmp(args[0], "ajuda")     == 0) cmd_help();
        else if (kstrcmp(args[0], "sobre")     == 0) cmd_sobre();
        else if (kstrcmp(args[0], "memoria")   == 0) cmd_memoria();
        else if (kstrcmp(args[0], "processos") == 0) cmd_processos();
        else if (kstrcmp(args[0], "limpar")    == 0) vga_clear();
        else if (kstrcmp(args[0], "eco")       == 0) cmd_eco(args, argc);
        else if (kstrcmp(args[0], "hex")       == 0) cmd_hex(args, argc);
        else if (kstrcmp(args[0], "cor")       == 0) cmd_cor(args, argc);
        else if (kstrcmp(args[0], "pag")       == 0) cmd_pag();
        else if (kstrcmp(args[0], "reboot")    == 0) cmd_reboot();
        else cmd_desconhecido(args[0]);
    }
}

#endif
