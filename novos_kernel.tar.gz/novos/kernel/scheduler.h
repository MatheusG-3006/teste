// =============================================================
//  NovOS — kernel/scheduler.h
//  Escalonador de processos — Round Robin simples
//
//  Cada processo tem sua própria pilha e contexto de CPU.
//  O escalonador alterna entre eles em fatias de tempo iguais.
// =============================================================

#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "../include/types.h"
#include "memory.h"

#define MAX_PROCS    16
#define STACK_SIZE   4096   // 4 KB de pilha por processo

// Estado de um processo
typedef enum {
    PROC_UNUSED  = 0,
    PROC_READY   = 1,
    PROC_RUNNING = 2,
    PROC_BLOCKED = 3,
    PROC_DEAD    = 4,
} ProcState;

// Contexto de CPU salvo em cada troca de contexto
typedef struct {
    u32 eax, ebx, ecx, edx;
    u32 esi, edi;
    u32 ebp, esp;
    u32 eip;
    u32 eflags;
} CPUContext;

// Bloco de controle de processo (PCB)
typedef struct {
    u32        pid;
    char       name[32];
    ProcState  state;
    CPUContext ctx;
    u8*        stack;
    u32        priority;
    u32        ticks;       // tempo de CPU consumido
} Process;

// Tabela de processos
static Process proc_table[MAX_PROCS];
static int     current_pid  = 0;
static int     proc_count   = 0;
static u32     next_pid     = 1;

// =============================================================
//  Inicializa o escalonador
// =============================================================
void sched_init(void) {
    for (int i = 0; i < MAX_PROCS; i++) {
        proc_table[i].state = PROC_UNUSED;
        proc_table[i].pid   = 0;
    }
    proc_count = 0;
}

// =============================================================
//  Cria um novo processo
//  entry_point: função C que será executada pelo processo
// =============================================================
int proc_create(const char* name, void (*entry_point)(void), u32 priority) {
    // Encontra slot livre
    int slot = -1;
    for (int i = 0; i < MAX_PROCS; i++) {
        if (proc_table[i].state == PROC_UNUSED) {
            slot = i;
            break;
        }
    }
    if (slot < 0) return -1; // tabela cheia

    Process* p = &proc_table[slot];

    // Copia nome
    int ni = 0;
    while (name[ni] && ni < 31) { p->name[ni] = name[ni]; ni++; }
    p->name[ni] = '\0';

    // Aloca pilha
    p->stack = (u8*)kmalloc(STACK_SIZE);
    u32 stack_top = (u32)(p->stack + STACK_SIZE);

    // Configura contexto inicial
    kmemset(&p->ctx, 0, sizeof(CPUContext));
    p->ctx.eip  = (u32)entry_point;  // PC aponta para a função
    p->ctx.esp  = stack_top - 4;     // topo da pilha
    p->ctx.ebp  = stack_top - 4;
    p->ctx.eflags = 0x202;           // interrupções habilitadas

    p->pid      = next_pid++;
    p->state    = PROC_READY;
    p->priority = priority;
    p->ticks    = 0;

    proc_count++;
    return p->pid;
}

// =============================================================
//  Retorna processo atual
// =============================================================
Process* proc_current(void) {
    for (int i = 0; i < MAX_PROCS; i++)
        if (proc_table[i].pid == (u32)current_pid)
            return &proc_table[i];
    return NULL;
}

// =============================================================
//  Escalonador Round-Robin
//  Chamado pelo timer para selecionar o próximo processo
// =============================================================
int sched_next(void) {
    // Incrementa ticks do processo atual
    for (int i = 0; i < MAX_PROCS; i++)
        if (proc_table[i].pid == (u32)current_pid)
            proc_table[i].ticks++;

    // Busca próximo processo READY (circular)
    int start = current_pid % MAX_PROCS;
    for (int i = 1; i <= MAX_PROCS; i++) {
        int idx = (start + i) % MAX_PROCS;
        if (proc_table[idx].state == PROC_READY) {
            proc_table[idx].state = PROC_RUNNING;
            // Coloca o anterior de volta em READY
            for (int j = 0; j < MAX_PROCS; j++)
                if (proc_table[j].pid == (u32)current_pid &&
                    proc_table[j].state == PROC_RUNNING)
                    proc_table[j].state = PROC_READY;
            current_pid = proc_table[idx].pid;
            return current_pid;
        }
    }
    return current_pid; // nenhum outro pronto, mantém atual
}

// =============================================================
//  Mata um processo
// =============================================================
void proc_kill(u32 pid) {
    for (int i = 0; i < MAX_PROCS; i++) {
        if (proc_table[i].pid == pid) {
            proc_table[i].state = PROC_DEAD;
            proc_count--;
            break;
        }
    }
}

// =============================================================
//  Lista todos os processos
// =============================================================
void proc_list(void (*print_fn)(const char*), void (*print_num)(u32)) {
    print_fn("PID  ESTADO    TICKS  NOME\n");
    print_fn("---  --------  -----  ----------------\n");
    for (int i = 0; i < MAX_PROCS; i++) {
        Process* p = &proc_table[i];
        if (p->state == PROC_UNUSED) continue;

        print_num(p->pid);
        print_fn("    ");

        const char* states[] = {"UNUSED","PRONTO","EXEC  ","BLOQ  ","MORTO "};
        print_fn(states[p->state]);
        print_fn("  ");
        print_num(p->ticks);
        print_fn("    ");
        print_fn(p->name);
        print_fn("\n");
    }
}

#endif
