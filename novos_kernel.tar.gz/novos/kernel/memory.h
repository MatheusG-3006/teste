// =============================================================
//  NovOS — kernel/memory.h
//  Gerenciador de memória — Alocador por bitmap
//
//  Divide a RAM em páginas de 4KB e rastreia quais estão
//  livres/usadas com um bitmap (1 bit por página)
// =============================================================

#ifndef MEMORY_H
#define MEMORY_H

#include "../include/types.h"

#define PAGE_SIZE       4096          // 4 KB por página
#define MAX_PAGES       1024          // suporta até 4 MB de RAM
#define HEAP_START      0x100000      // heap começa em 1 MB (acima do kernel)

// Bitmap: cada bit representa uma página (0=livre, 1=usada)
static u32 page_bitmap[MAX_PAGES / 32];
static u32 total_pages    = 0;
static u32 used_pages     = 0;

// Endereço do heap para alocação simples (bump allocator)
static u8* heap_ptr = (u8*)HEAP_START;

// =============================================================
//  Inicializa o gerenciador de memória
// =============================================================
void mem_init(u32 ram_kb) {
    total_pages = (ram_kb * 1024) / PAGE_SIZE;
    if (total_pages > MAX_PAGES) total_pages = MAX_PAGES;

    // Marca todas as páginas como livres
    for (int i = 0; i < MAX_PAGES / 32; i++)
        page_bitmap[i] = 0;

    // Marca páginas do kernel (0 a 1MB) como usadas
    u32 kernel_pages = HEAP_START / PAGE_SIZE;
    for (u32 i = 0; i < kernel_pages; i++) {
        page_bitmap[i / 32] |= (1 << (i % 32));
        used_pages++;
    }
}

// =============================================================
//  Marca uma página como usada
// =============================================================
static void page_set(u32 idx) {
    page_bitmap[idx / 32] |= (1 << (idx % 32));
}

// =============================================================
//  Marca uma página como livre
// =============================================================
static void page_clear(u32 idx) {
    page_bitmap[idx / 32] &= ~(1 << (idx % 32));
}

// =============================================================
//  Verifica se uma página está livre
// =============================================================
static bool page_is_free(u32 idx) {
    return !(page_bitmap[idx / 32] & (1 << (idx % 32)));
}

// =============================================================
//  Aloca uma página de 4KB — retorna endereço físico
// =============================================================
void* page_alloc(void) {
    for (u32 i = 0; i < total_pages; i++) {
        if (page_is_free(i)) {
            page_set(i);
            used_pages++;
            return (void*)(i * PAGE_SIZE);
        }
    }
    return NULL; // sem memória livre
}

// =============================================================
//  Libera uma página de 4KB
// =============================================================
void page_free(void* addr) {
    u32 idx = (u32)addr / PAGE_SIZE;
    if (idx < total_pages && !page_is_free(idx)) {
        page_clear(idx);
        used_pages--;
    }
}

// =============================================================
//  Alocador simples (kmalloc) — bump pointer no heap
//  Não libera memória individualmente (suficiente para kernel)
// =============================================================
void* kmalloc(size_t size) {
    void* ptr = heap_ptr;
    heap_ptr += size;
    // Alinha para 4 bytes
    heap_ptr = (u8*)(((u32)heap_ptr + 3) & ~3);
    return ptr;
}

// =============================================================
//  memset / memcpy do kernel (sem libc)
// =============================================================
void* kmemset(void* dest, u8 val, size_t n) {
    u8* d = (u8*)dest;
    while (n--) *d++ = val;
    return dest;
}

void* kmemcpy(void* dest, const void* src, size_t n) {
    u8* d = (u8*)dest;
    const u8* s = (const u8*)src;
    while (n--) *d++ = *s++;
    return dest;
}

// =============================================================
//  Retorna memória livre em KB
// =============================================================
u32 mem_free_kb(void) {
    return ((total_pages - used_pages) * PAGE_SIZE) / 1024;
}

u32 mem_used_kb(void) {
    return (used_pages * PAGE_SIZE) / 1024;
}

u32 mem_total_kb(void) {
    return (total_pages * PAGE_SIZE) / 1024;
}

#endif
