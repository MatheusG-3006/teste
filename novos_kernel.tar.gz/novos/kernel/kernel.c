// =============================================================
//  NovOS — kernel/kernel.c
//  Ponto de entrada principal do Kernel Aether
//
//  Executado imediatamente após o bootloader em modo
//  protegido 32-bit. Não há libc — tudo é do zero.
// =============================================================

#include "../include/types.h"
#include "../drivers/vga.h"
#include "../drivers/keyboard.h"
#include "memory.h"
#include "scheduler.h"
#include "shell.h"

// =============================================================
//  Processos de exemplo (rodam no escalonador)
// =============================================================
void proc_idle(void) {
    // Processo idle: apenas executa HLT em loop
    while (1) __asm__ volatile ("hlt");
}

void proc_system(void) {
    // Processo do sistema: mantém contadores internos
    while (1) {
        // Em um SO real: gerenciaria timers, I/O, etc.
        __asm__ volatile ("nop");
    }
}

// =============================================================
//  Desenha banner de boas-vindas
// =============================================================
static void draw_banner(void) {
    vga_clear();

    // Barra de título
    vga_hline(0, ' ', COLOR_BLACK, COLOR_LCYAN);
    vga_print_at("  NovOS v1.0 - Kernel Aether 1.0 - Modo Protegido 32-bit",
                 0, 0, COLOR_BLACK, COLOR_LCYAN);

    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("\n\n");

    // ASCII art do logo
    vga_set_color(COLOR_LCYAN, COLOR_BLACK);
    vga_print("    _   _           ____  ____  \n");
    vga_print("   | \\ | | _____   / __ \\/ ___| \n");
    vga_print("   |  \\| |/ _ \\ \\ / / / /\\___ \\ \n");
    vga_print("   | |\\  | (_) \\ V / /_/ / ___) |\n");
    vga_print("   |_| \\_|\\___/ \\_/ \\____/ |____/ \n");
    vga_print("\n");

    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("   Sistema Operacional Independente\n");
    vga_print("   Kernel Aether | FS Vortex | CipherCore\n");
    vga_print("   Arquitetura: x86 32-bit Protected Mode\n\n");

    // Linha separadora
    vga_set_color(COLOR_CYAN, COLOR_BLACK);
    for (int i = 0; i < 78; i++) vga_putchar('-');
    vga_putchar('\n');
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
}

// =============================================================
//  Inicialização dos subsistemas
// =============================================================
static void kernel_init(void) {
    // 1. Inicializa gerenciador de memória (assumindo 4 MB de RAM)
    mem_init(4096);

    // 2. Inicializa escalonador
    sched_init();

    // 3. Cria processos do sistema
    proc_create("idle",   proc_idle,   0);
    proc_create("system", proc_system, 1);
    proc_create("novshell", shell_run, 2);  // shell como processo

    // Reporta inicialização
    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] Kernel Aether inicializado\n");

    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] Gerenciador de memoria: ");
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print_num(mem_total_kb());
    vga_print(" KB total, ");
    vga_print_num(mem_free_kb());
    vga_print(" KB livres\n");

    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] Escalonador Round-Robin ativo\n");

    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] Driver VGA modo texto 80x25\n");

    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] Driver teclado PS/2 (porta 0x60)\n");

    vga_set_color(COLOR_LGREEN, COLOR_BLACK);
    vga_print("  [OK] NovShell pronto\n\n");

    vga_set_color(COLOR_CYAN, COLOR_BLACK);
    for (int i = 0; i < 78; i++) vga_putchar('-');
    vga_putchar('\n');
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_print("\n");
}

// =============================================================
//  PONTO DE ENTRADA DO KERNEL
//  Chamado pelo bootloader após entrar em modo protegido
// =============================================================
void kernel_main(void) {
    // Configura cor padrão e limpa tela
    vga_set_color(COLOR_LGRAY, COLOR_BLACK);
    vga_clear();

    // Banner
    draw_banner();

    // Inicializa subsistemas
    kernel_init();

    // Inicia shell diretamente (em SO real seria via escalonador)
    shell_run();

    // Nunca deve chegar aqui
    // Em SO real: loop do escalonador com HLT entre interrupções
    while (1) __asm__ volatile ("hlt");
}
