// =============================================================
//  NovOS — drivers/keyboard.h
//  Driver de teclado PS/2 — leitura por polling da porta 0x60
// =============================================================

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "../include/types.h"

#define KB_DATA_PORT   0x60   // porta de dados do teclado PS/2
#define KB_STATUS_PORT 0x64   // porta de status

// Lê um byte de uma porta de I/O
static inline u8 inb(u16 port) {
    u8 val;
    __asm__ volatile ("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

// Buffer circular de teclado
#define KB_BUF_SIZE 128
static char kb_buf[KB_BUF_SIZE];
static int  kb_buf_head = 0;
static int  kb_buf_tail = 0;

// Mapa de scancodes (Set 1) para caracteres ASCII
// Índice = scancode, valor = caractere ASCII
static const char scancode_map[128] = {
    0,   27,  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
    '-', '=', '\b','\t','q', 'w', 'e', 'r', 't', 'y', 'u', 'i',
    'o', 'p', '[', ']', '\n', 0,  'a', 's', 'd', 'f', 'g', 'h',
    'j', 'k', 'l', ';', '\'','`', 0,  '\\','z', 'x', 'c', 'v',
    'b', 'n', 'm', ',', '.', '/', 0,  '*', 0,   ' ', 0,
    // F1-F10, etc. mapeados como 0
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,
};

// Verifica se há dado pronto na porta do teclado
static inline bool kb_has_data(void) {
    return inb(KB_STATUS_PORT) & 0x01;
}

// =============================================================
//  Lê tecla pressionada (bloqueante — aguarda input)
// =============================================================
char kb_getchar(void) {
    while (1) {
        if (!kb_has_data()) continue;

        u8 scancode = inb(KB_DATA_PORT);

        // Ignora teclas soltas (bit 7 = 1 significa "key up")
        if (scancode & 0x80) continue;

        // Converte scancode para ASCII
        char c = (scancode < 128) ? scancode_map[scancode] : 0;
        if (c != 0) return c;
    }
}

// =============================================================
//  Lê uma linha inteira (com eco na tela)
//  Termina com Enter, suporta Backspace
// =============================================================
int kb_readline(char* buf, int maxlen, void (*echo_fn)(char)) {
    int i = 0;
    while (i < maxlen - 1) {
        char c = kb_getchar();
        if (c == '\n') {
            if (echo_fn) echo_fn('\n');
            break;
        } else if (c == '\b') {
            if (i > 0) {
                i--;
                if (echo_fn) echo_fn('\b');
            }
        } else {
            buf[i++] = c;
            if (echo_fn) echo_fn(c);
        }
    }
    buf[i] = '\0';
    return i;
}

#endif
