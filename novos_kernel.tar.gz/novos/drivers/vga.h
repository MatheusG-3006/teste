// =============================================================
//  NovOS — drivers/vga.h
//  Driver de vídeo VGA modo texto 80x25
//  Acesso direto à memória de vídeo em 0xB8000
// =============================================================

#ifndef VGA_H
#define VGA_H

#include "../include/types.h"

// Memória de vídeo VGA (modo texto)
#define VGA_BASE    ((volatile u16*)0xB8000)
#define VGA_COLS    80
#define VGA_ROWS    25

// Cores VGA
typedef enum {
    COLOR_BLACK   = 0,
    COLOR_BLUE    = 1,
    COLOR_GREEN   = 2,
    COLOR_CYAN    = 3,
    COLOR_RED     = 4,
    COLOR_MAGENTA = 5,
    COLOR_BROWN   = 6,
    COLOR_LGRAY   = 7,
    COLOR_DGRAY   = 8,
    COLOR_LBLUE   = 9,
    COLOR_LGREEN  = 10,
    COLOR_LCYAN   = 11,
    COLOR_LRED    = 12,
    COLOR_LMAGENTA= 13,
    COLOR_YELLOW  = 14,
    COLOR_WHITE   = 15,
} VGAColor;

// Variáveis de estado
static int cursor_x = 0;
static int cursor_y = 0;
static u8  current_color = 0;

// Monta byte de atributo: fundo (4 bits) | frente (4 bits)
static inline u8 make_color(VGAColor fg, VGAColor bg) {
    return (bg << 4) | fg;
}

// Monta entrada VGA: atributo (8 bits) | caractere (8 bits)
static inline u16 make_entry(char c, u8 color) {
    return (u16)c | ((u16)color << 8);
}

// Apaga a tela inteira
void vga_clear(void) {
    u8 color = make_color(COLOR_LGRAY, COLOR_BLACK);
    for (int y = 0; y < VGA_ROWS; y++)
        for (int x = 0; x < VGA_COLS; x++)
            VGA_BASE[y * VGA_COLS + x] = make_entry(' ', color);
    cursor_x = 0;
    cursor_y = 0;
}

// Define cor atual
void vga_set_color(VGAColor fg, VGAColor bg) {
    current_color = make_color(fg, bg);
}

// Rola tela uma linha para cima
static void vga_scroll(void) {
    for (int y = 0; y < VGA_ROWS - 1; y++)
        for (int x = 0; x < VGA_COLS; x++)
            VGA_BASE[y * VGA_COLS + x] = VGA_BASE[(y+1) * VGA_COLS + x];
    // Limpa última linha
    u8 color = make_color(COLOR_LGRAY, COLOR_BLACK);
    for (int x = 0; x < VGA_COLS; x++)
        VGA_BASE[(VGA_ROWS-1) * VGA_COLS + x] = make_entry(' ', color);
    cursor_y = VGA_ROWS - 1;
}

// Imprime um caractere na posição do cursor
void vga_putchar(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 4) & ~3;
    } else if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            VGA_BASE[cursor_y * VGA_COLS + cursor_x] = make_entry(' ', current_color);
        }
    } else {
        VGA_BASE[cursor_y * VGA_COLS + cursor_x] = make_entry(c, current_color);
        cursor_x++;
    }

    if (cursor_x >= VGA_COLS) {
        cursor_x = 0;
        cursor_y++;
    }
    if (cursor_y >= VGA_ROWS)
        vga_scroll();
}

// Imprime string
void vga_print(const char* str) {
    while (*str) vga_putchar(*str++);
}

// Imprime string na posição específica com cor
void vga_print_at(const char* str, int x, int y, VGAColor fg, VGAColor bg) {
    u8 color = make_color(fg, bg);
    int col = x;
    while (*str && col < VGA_COLS) {
        VGA_BASE[y * VGA_COLS + col] = make_entry(*str, color);
        str++;
        col++;
    }
}

// Imprime número inteiro (decimal)
void vga_print_int(int n) {
    if (n < 0) { vga_putchar('-'); n = -n; }
    if (n == 0) { vga_putchar('0'); return; }
    char buf[12];
    int i = 0;
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    while (i-- > 0) vga_putchar(buf[i+1] > 0 ? buf[i+1] : buf[0]);
    // correção simples:
    // reimprime invertido
}

// Imprime número inteiro corretamente
void vga_print_num(u32 n) {
    if (n == 0) { vga_putchar('0'); return; }
    char buf[12];
    int i = 0;
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    for (int j = i-1; j >= 0; j--) vga_putchar(buf[j]);
}

// Imprime número em hexadecimal
void vga_print_hex(u32 n) {
    const char* hex = "0123456789ABCDEF";
    vga_print("0x");
    for (int i = 28; i >= 0; i -= 4)
        vga_putchar(hex[(n >> i) & 0xF]);
}

// Imprime linha horizontal
void vga_hline(int y, char c, VGAColor fg, VGAColor bg) {
    u8 color = make_color(fg, bg);
    for (int x = 0; x < VGA_COLS; x++)
        VGA_BASE[y * VGA_COLS + x] = make_entry(c, color);
}

#endif
